<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
	{
		 parent::__construct();
		 $this->load->database();
         $this->load->helper(array('form', 'url'));
		
		/*cache control*/
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
    }
	public function index()
	{
		if ($this->session->has_userdata('username')){

		}else{
			$this->load->view('login');

		}	
		
	}
	public function registration()
	{
		$this->load->view('registration');
	}
	public function insert_user_registration(){
			$name    = $this->input->post('name');
            $email    = $this->input->post('email');
            $mobile    = $this->input->post('mobile');
            $password = $this->input->post('password');
            $data['user_name']=$name;
            $data['email_id']=$email;
            $data['mobile']=$mobile;
            $data['password']=$password;
            
		$this->db->insert('user_details' , $data);
		redirect('Welcome');
	}

	public function dashboard(){

			$this->load->view('login');
			
	}

	public function check_log_submit(){

			$username    = $this->input->post('username');
            $password = $this->input->post('password');
          
		   
		    	$arr['h']=array();
            $login_counter = $this->db->get_where('user_details' , array('email_id' => $username,'password'=>$password))->row()->login_counter;
            if(sizeof($login_counter)>0){
            $login_counter=($login_counter+1);
            	
              	$this->db->where('email_id', $username);
				 $this->db->update('user_details', array('login_counter' => $login_counter));
				array_push($arr['h'], $login_counter);
				$logout_counter = $this->db->get_where('user_details' , array('email_id' => $username))->row()->logout_counter;
				array_push($arr['h'], $logout_counter);
				$newdata = array(
        		'username'  =>$username ,
        		'logged_in' => TRUE
			);
				$this->session->set_userdata($newdata);
            $this->load->view('dashboard',$arr);

		    }else{

		    	echo "<script type='text/javascript'>alert('Sorry!! Invalid Username/Password.');</script>";
		    	redirect('http://'.$_SERVER['SERVER_NAME'].'/LoginRegistrationPro/','refresh');
		    }
            
             
	}

	public function logout(){
		$username=$_SESSION['username'];
		$logout_counter = $this->db->get_where('user_details' , array('email_id' => $username))->row()->logout_counter;
			$logout_counter=($logout_counter+1);
			$this->db->where('email_id', $username);
			$this->db->update('user_details', array('logout_counter' => $logout_counter));
		$data = array('username' => '');
        $this->session->unset_userdata($data);
        $this->session->sess_destroy();
        $this->session->flashdata('username');
		redirect('http://'.$_SERVER['SERVER_NAME'].'/LoginRegistrationPro/','refresh');
	}
}
