<!DOCTYPE html>
<html lang="en">
<head>
  <title>User|Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:700,300,600,400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet"  href="<?php echo base_url();?>css/main.css">
  
</head>
<body class="landing" background="<?php echo base_url('Assets/images/landing.png');?>">
    <div class="container" >
        <div class="col-sm-4" ></div>
            <div class="col-sm-4"  style="background-color: white ;border-radius: 10px;opacity:0.9;color: black;text-shadow: none;margin-top:150px" >
            <br>
             <h6 style="color:rgb(90,90,90);text-align:center;font-size:30px;font-family: sans-serif">USER</h6>
            <h6 style="color:rgb(90,90,90);text-align:center;font-size:25px;font-family: Verdana">LOGIN</h6>
            <form style="margin-top: 40px" method="POST" action="<?php echo site_url('Welcome/check_log_submit');?>">
              <div class="form-group" >
                    <div class="input-group">
                          <span class="input-group-addon" >
                            <img src="<?php echo base_url('Assets/images/username.png');?>" width="20px" height="20px">
                                </span>
                            <input type="text" id="username" name="username" name="names" class="form-control" aria-describedby="basic-addon1" placeholder="Username/Email Id">
                    </div>
                    <div id="checkemail" style="color:red;font-size:15px;">
                      
                    </div>
              </div>
    

              <div class="form-group">
                    <div class="input-group">
                          <span class="input-group-addon" >
                            <img src="<?php echo base_url('Assets/images/password.png');?>" width="20px" height="20px">
                          </span>
                            <input type="password" id="password" name="password" class="form-control" aria-describedby="basic-addon1" placeholder="Password">
                    </div>
                    <div id="checkpassword" style="color:red;font-size:15px;"></div>
              </div>

                          <button id="demo" type="submit"  class="btn btn-primary btn-block" value="submit" style="height:45px">LOGIN</button> 
                          <a href="<?php echo site_url("Welcome/registration"); ?>"><h5 style="text-align: right;color: seagreen">Dont have account?click to register</h5></a>     
            </form>
                <br><br><br>
          </div>
        <div class="col-sm-4" ></div>
    </div>

    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">DAHBOARD</h4>
        </div>
        <div class="modal-body">
          <p>LOGIN-COUNTER:</p>
          <div id="log_count"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  

</body>

       
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        
</html>
