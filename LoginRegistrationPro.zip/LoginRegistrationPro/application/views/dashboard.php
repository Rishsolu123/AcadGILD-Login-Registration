
<!DOCTYPE html>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>User|Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:700,300,600,400' rel='stylesheet' type='text/css'>
    <link rel="stylesheet"  href="<?php echo base_url();?>css/main.css">
  
</head>
<body class="landing" background="<?php echo base_url('Assets/images/landing.png');?>">
    <div class="container" >
        <div class="col-sm-4" ></div>
            <div class="col-sm-4"  style="background-color: white ;border-radius: 10px;opacity:0.9;color: black;text-shadow: none;margin-top:150px" >
            <br>
             
            <form style="margin-top: 40px" method="POST" action="<?php echo site_url('Welcome/logout');?>">
             <?php 
             $counter=0;
            foreach ($h as $row) {
              if($counter==0){
            ?>
                <h4 style="color: black">Login count: <?php echo $row; ?></p>
          <?php
            }else{?>
            <h4 style="color: black">Logout count: <?php echo $row; ?></p>
            <?php

            }
            $counter++;

                }
          ?>   
          <button class="btn btn-danger pull-right">Logout</button>
            </form>
                <br><br><br>
          </div>
        <div class="col-sm-4" ></div>
    </div>

 
  

</body>

       
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        
</html>
